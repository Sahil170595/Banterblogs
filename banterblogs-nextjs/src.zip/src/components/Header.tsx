'use client';

import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { SearchDialog } from './SearchDialog';
import { GITHUB_URLS } from '@/lib/constants';

const NAV_ITEMS = [
  { href: '/platform', label: 'Platform' },
  { href: '/episodes', label: 'Episodes' },
  { href: '/technology', label: 'Technology' },
  { href: '/about', label: 'About' },
  { href: '/tags', label: 'Tags' },
];

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-[72px] items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-base font-bold text-primary-foreground shadow-lg shadow-primary/30">
            BB
          </span>
          <span className="hidden text-lg font-semibold tracking-tight text-foreground sm:inline-block display">
            Building Jarvis
          </span>
        </Link>

        <div className="flex flex-1 items-center justify-end gap-4">
          <div className="hidden flex-1 md:block">
            <SearchDialog />
          </div>

          <nav className="hidden items-center gap-1 text-sm font-semibold text-muted-foreground md:flex">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="rounded-full px-3 py-2 transition hover:bg-primary/10 hover:text-primary"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href={GITHUB_URLS.BANTERBLOGS}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border border-border/60 px-4 py-2 text-foreground transition hover:border-primary/60 hover:text-primary"
            >
              GitHub
            </Link>
          </nav>

          <button
            className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground transition hover:text-foreground md:hidden"
            onClick={() => setIsMenuOpen((prev) => !prev)}
            aria-label="Toggle navigation"
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="border-t border-border/60 bg-background/95 backdrop-blur md:hidden">
          <div className="container space-y-1 py-6">
            <div className="mb-4">
              <SearchDialog />
            </div>
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="block rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition hover:bg-primary/10 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href={GITHUB_URLS.BANTERBLOGS}
              target="_blank"
              rel="noopener noreferrer"
              className="block rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition hover:bg-primary/10 hover:text-primary"
              onClick={() => setIsMenuOpen(false)}
            >
              GitHub
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}